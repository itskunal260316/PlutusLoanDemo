export class Car {

    constructor(public carModel?: String,
        public carMake?: String,
        public exShowroomPrice?: number,
        public onRoadPrice?:number,
 
    ) {

    }
}