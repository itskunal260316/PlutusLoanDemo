export class Registration {

    constructor(public firstName?: String,
        public lastName?: String,
        public age?: number,
        public gender?: String,
        public mobile?: String,
        public emailId?: String,
        public password?: String,
        public address?: String,
        public state?: String,
        public city?: String,
        public pincode?: String,
    ) {

    }
}