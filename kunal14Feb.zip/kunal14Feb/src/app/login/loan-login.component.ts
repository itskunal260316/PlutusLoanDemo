import { Component } from '@angular/core';
import { Login } from './login';
import { LoginService } from './login-service';
import { Router } from '@angular/router';

@Component({
  selector: 'loan-login',
  templateUrl: './loan-login.component.html',
  styleUrls: ['./loan-login.component.css']
})

export class LoanLoginComponent {

  login: Login = new Login();
  response: string;

  constructor(private loginService: LoginService, private router: Router) {

  }

  loanlogin(loginform) {

    this.loginService.loginFromServer(this.login)
      .subscribe(data => {
        this.response = data['status'];
        console.log(this.response)
   
    if (this.response === 'Login successfully!') {
      this.router.navigate(['./home-page']);
    }
    else {
      this.router.navigate(['./loan-login']);

    }
      })



  }
}