import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Application } from '../application/application';
import { Eligibility } from './eligibility';

const httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable()
export class ContactService {
    eligibility: Eligibility=new Eligibility();
  

    constructor(private http: HttpClient) {
    }

    checkEligibility(application: Application): Observable<String> {
        console.log(application.employmentType);
        this.eligibility.age= application.age;
        this.eligibility.existingEmi=application.existingEmi;
        this.eligibility.amount=2000;
        this.eligibility.tenure=application.tenure;
        this.eligibility.yearlySalary=application.yearlySalary;

        console.log(this.eligibility.existingEmi);
        console.log(this.eligibility.tenure);
        console.log(this.eligibility.yearlySalary);
        console.log(this.eligibility.amount);

        //var token = currentUser.token;
        let url = "http://localhost:8281/eligibility/check";
        return this.http.post<String>(url,this.eligibility);

    }
}