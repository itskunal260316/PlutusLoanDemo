export class Details{

    constructor(public emailId?:string,
        public mobile?: string,
        )
        {

        }
}