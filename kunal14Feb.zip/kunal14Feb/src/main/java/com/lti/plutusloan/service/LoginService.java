package com.lti.plutusloan.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.plutusloan.dto.LoginDTO;
import com.lti.plutusloan.repository.LoginRepository;

@Service
public class LoginService {

	@Autowired
	LoginRepository loginRepository;

	@Transactional
	public boolean validateUser(LoginDTO loginLoanDTO) {
		if ( loginRepository.fetchUser(loginLoanDTO) != null)
			return true;

		return false;
	}
	
}
