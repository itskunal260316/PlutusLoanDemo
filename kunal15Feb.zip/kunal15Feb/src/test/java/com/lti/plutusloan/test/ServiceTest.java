package com.lti.plutusloan.test;


import javax.imageio.spi.RegisterableService;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import com.lti.plutusloan.dto.EmiDTO;
import com.lti.plutusloan.dto.LoginDTO;
import com.lti.plutusloan.dto.RegistrationDTO;
import com.lti.plutusloan.entity.Registration;
import com.lti.plutusloan.service.EmiCalculatorService;
import com.lti.plutusloan.service.LoginService;
import com.lti.plutusloan.service.RegistrationService;
@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureTestDatabase(replace=Replace.NONE)
public class ServiceTest {



		@Autowired
		EmiCalculatorService calculator;
		@Autowired
		RegistrationService registrationService;
		@Autowired
		LoginService loginService;

		@Test
		public void testEMI() {

			EmiDTO emiDTO = new EmiDTO();
			emiDTO.setPrincipal(50000);
			emiDTO.setRateOfInterest(7.5);
			emiDTO.setTenure(7);

			System.out.println(calculator.calculateEmi(emiDTO));
		}

		@Test
		public void testRegistration() {

			RegistrationDTO registrationDTO = new RegistrationDTO();
			registrationDTO.setFirstName("Hari");
			registrationDTO.setLastName("Shetty");
			registrationDTO.setAge(25);
			registrationDTO.setGender("M");
			registrationDTO.setMobile("9782234578");
			registrationDTO.setEmailId("harishetty@gmail.com");
			registrationDTO.setPassword("hello123");
			registrationDTO.setConfirmPassword("hello123");
			registrationDTO.setAddress("A/101,Vasant Vihar, Thane");
			registrationDTO.setCity("Mumbai");
			registrationDTO.setState("Maharashtra");
			registrationDTO.setPincode("400101");

			if (registrationDTO.getPassword() == registrationDTO.getConfirmPassword()) {
				Registration registration = new Registration();
				registration.setFirstName(registrationDTO.getFirstName());
				registration.setLastName(registrationDTO.getLastName());
				registration.setAge(registrationDTO.getAge());
				registration.setGender(registrationDTO.getGender());
				registration.setMobile(registrationDTO.getMobile());
				registration.setEmailId(registrationDTO.getEmailId());
				registration.setPassword(registrationDTO.getPassword());
				registration.setAddress(registrationDTO.getAddress());
				registration.setCity(registrationDTO.getCity());
				registration.setState(registrationDTO.getState());
				registration.setPincode(registrationDTO.getPincode());
				registration.setRole(0);
				registrationService.registerUser(registration);
			}

			else
				System.out.println("Registration not successful");

		}

		@Test
		public void testLogin() {
			LoginDTO loginDTO = new LoginDTO();
			loginDTO.setEmailId("harishetty@gmail.com");
			loginDTO.setPassword("hello123");
			loginDTO.setRole(0);
			if (loginService.validateUser(loginDTO))
				System.out.println("Successfully Logged in");
			else
				System.out.println("Incorrect email or password");

	}
}