

package com.lti.plutusloan.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.plutusloan.entity.Registration;
import com.lti.plutusloan.repository.GenericRepository;


@Service
public class RegistrationService {
	@Autowired
	private GenericRepository genericRepository;

	@Transactional
	public void registerUser(Registration register) {
		genericRepository.store(register);
	}
}


