package com.lti.plutusloan.service;

import org.springframework.stereotype.Service;

import com.lti.plutusloan.dto.EmiDTO;

@Service
public class EmiCalculatorService {

	public double calculateEmi(EmiDTO emiDTO) {	
		return( emiDTO.getPrincipal() * emiDTO.getRateOfInterest()/(Math.pow(1+ emiDTO.getRateOfInterest(),emiDTO.getTenure())/((Math.pow(1+ emiDTO.getRateOfInterest(),emiDTO.getTenure())-1))));
	}
}
