import { Component } from '@angular/core';

@Component({
  selector: 'access-page',
  templateUrl: './access-page.component.html'
})

export class AccessPageComponent {

}