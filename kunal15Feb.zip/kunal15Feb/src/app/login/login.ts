export class Login{

    constructor(public emailId?:String,
        public password?:String,
        public role?: number,
        )
        {

        }
}