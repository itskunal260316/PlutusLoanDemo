import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Car } from './car';
import { Observable } from 'rxjs';

const httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  };
  
  @Injectable()
  export class CarService {
  
    constructor(private http: HttpClient) {
  
    }
  
    fetchCarList(car: Car): Observable<String> {
      let url = "http://localhost:8281/loan/carList";
      return this.http.post<String>(url, car);
  
    }
}