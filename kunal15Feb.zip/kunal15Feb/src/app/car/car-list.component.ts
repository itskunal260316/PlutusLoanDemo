import { Component } from '@angular/core';
import { Car } from './car';
import { CarService } from './car-service';
import { Router } from '@angular/router';

@Component({
    selector: 'car-list',
    templateUrl: './car-list.component.html',
    styleUrls: ['./car-list.component.css']
  })

  export class CarListComponent {

    car:Car=new Car();
    response: String;

    constructor(private carService: CarService, private router: Router) {

    }

    loadCarList() {
        this.carService.fetchCarList(this.car)
        .subscribe(data => {
          this.response = data;
          console.log(this.response)})

    }

    carDetailSubmit(){
        this.router.navigate(['./application-form']);
    }
    
  }