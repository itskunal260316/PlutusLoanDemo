import { Component } from '@angular/core';
import { Emi } from './emi';
import { Router } from '@angular/router';
import { EmiService } from './emi-service';

@Component({
  selector: 'emi-calculator',
  templateUrl: './calculate-emi.component.html',
  styleUrls: ['./calculate-emi.component.css']
})

export class EmiCalculatorComponent {

  emi: Emi = new Emi();
  response: number;

  constructor(private emiService: EmiService, private router: Router) {

  }

  calculateEmi(): number {

    this.emiService.calculateEmiFromServer(this.emi)
    .subscribe(data => {
      this.response= data;
      console.log(this.response)
    })
    return this.response;
  }


}