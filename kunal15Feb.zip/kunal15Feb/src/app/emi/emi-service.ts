import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Emi } from './emi';
import { Observable } from 'rxjs';

const httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  };
  
  @Injectable()
  export class EmiService {
    //emi: Emi[];
  
    constructor(private http: HttpClient) {
    }
  
    calculateEmiFromServer(emi: Emi): Observable<number> {
      let url = "http://localhost:8281/emi/calculate";
      return this.http.post<number>(url, emi);
  
    }
  }