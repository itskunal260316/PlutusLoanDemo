export class Emi{

    constructor(public principal?:number,
        public rateOfInterest?: number,
        public tenure?: number,
        )
        {

        }
}