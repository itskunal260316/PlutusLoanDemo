import { Component } from '@angular/core';
import { Registration } from './registration'
import { RegistrationService } from './registration-service'
import { Router } from '@angular/router';

@Component({
  selector: 'loan-registration',
  templateUrl: './loan-registration.component.html',
  styleUrls: ['./loan-registration.component.css']
})

export class LoanRegistrationComponent {

  registration: Registration = new Registration();
  response: string;

  constructor(private registrationService: RegistrationService, private router: Router) {

  }

  loanregistration() {

    this.registrationService.registerToServer(this.registration)
      .subscribe(data => {
        this.response = data['status'];
        console.log(this.response)
        
    if (this.response  === 'Registration done successfully!') {
      this.router.navigate(['./loan-login']);

    }
    else {
      this.router.navigate(['./loan-registration']);

    }
      })


  }

}
