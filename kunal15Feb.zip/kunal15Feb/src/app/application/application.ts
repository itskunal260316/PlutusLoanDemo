export class Application{

    constructor(public firstName?:string,
        public lastName?:string,
        public age?: number,
        public gender?:string,
        public employmentType?:string,
        public yearlySalary?:number,
        public existingEmi?:number,
        public tenure?:number,
        public accountType?:string

        )
        {

        }
}