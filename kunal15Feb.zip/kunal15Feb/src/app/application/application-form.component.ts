import { Component } from '@angular/core';
import { Application } from './application';
import { Router } from '@angular/router';

@Component({
  selector: 'application-form',
  templateUrl: './application-form.component.html',
  styleUrls: ['./application-form.component.css']
})

export class ApplicationFormComponent {

  application: Application = new Application();
  response: number;
  constructor(private router: Router) {

  }

  saveApplicantDetails(applicationform): void {
    window.localStorage.setItem('applicantDetails', JSON.stringify({ token: this.application, name: 'applicantDetails' }));
    this.router.navigate(['./contact-form']);

  }


}