export class Eligibility{

    constructor(public age?:number,
        public existingEmi?: number,
        public yearlySalary?: number,
        public amount?: number,
        public tenure?: number

        )
        {

        }
}