import { Component } from '@angular/core';
import { Details } from './details'
import { Router } from '@angular/router';
import { ContactService } from './contact-service';
import { Application } from '../application/application';

@Component({
  selector: 'contact-form',
  templateUrl: './contact-details.component.html',
  styleUrls: ['./contact-details.component.css']
})

export class ContactDetailsComponent {

  details: Details = new Details();
  response: string;
  application: Application = new Application();


  constructor(private contactService: ContactService, private router: Router) {

  }

  savePersonalDetails(detailsform) {
    localStorage.setItem('personalDetails', JSON.stringify({ token: this.details, name: 'personal-details' }));
    this.application = JSON.parse(localStorage.getItem('applicantDetails'))['token'];

    this.contactService.checkEligibility(this.application)
      .subscribe(data => {
        this.response = data['status'];
      })
  }
}