import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { FormsModule } from '@angular/forms';
import { HomePageComponent } from './home/home.component';
import { EmiCalculatorComponent } from './emi/calculate-emi.component';
import { RouterModule } from '@angular/router';
import { LoanLoginComponent } from './login/loan-login.component';
import { LoanRegistrationComponent } from './registration/loan-registration.component';
import { RegistrationService } from './registration/registration-service';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { LoginService } from './login/login-service';
import { EmiService } from './emi/emi-service';
import { ApplicationFormComponent } from './application/application-form.component';
import { ContactDetailsComponent } from './contact-details/contact-details.component';
import { ContactService } from './contact-details/contact-service';
import { CarListComponent } from './car/car-list.component';
import { AccessPageComponent } from 'src/access-page/access-page.component';

@NgModule({
  declarations: [
    AppComponent, 
    HomePageComponent,
    EmiCalculatorComponent,
    LoanLoginComponent,
    LoanRegistrationComponent,
    EmiCalculatorComponent,
    ApplicationFormComponent,
    ContactDetailsComponent,
    CarListComponent,
    AccessPageComponent,

  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot([ 
      {path:'home-page', component: HomePageComponent},
    {path:'emi-calculator', component: EmiCalculatorComponent},
    {path:'loan-login', component: LoanLoginComponent},
    {path:'loan-registration', component:  LoanRegistrationComponent},
    {path:'application-form', component:  ApplicationFormComponent},
    {path:'contact-form', component:  ContactDetailsComponent},
    {path:'access-page', component:  AccessPageComponent},
  ])
   
  ],
  providers: [HttpClient,RegistrationService,LoginService,EmiService,ContactService],
  bootstrap: [AppComponent]
})
export class AppModule { }
